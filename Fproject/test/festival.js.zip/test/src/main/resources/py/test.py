def testFunc(a,b):
    print("teestestsetsetst")
    c = a+b
    return c